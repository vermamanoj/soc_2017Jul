#!/usr/bin/env python3
# This sample demonstrates how to encode credentials, how to format and attach
# headers to an HTTP request, and how to send a simple request to a REST API
# endpoint. This script uses many python modules directly in order to
# demonstrate the low level functionality of the API. Future scripts will wrap
# this functionality into shared modules for re-use.

# For a list of the endpoints that you can use along with the parameters that
# they accept you can view the REST API interactive help page on your
# deployment at https://<hostname>/api_doc
# You can also retrieve a list of available endpoints through the API itself
# at the /api/help/versions endpoint.

import base64
import configparser
import json
import ssl
import sys
import os
import urllib.request
import getpass


def q_auth(*id):
    host = "52.90.13.59"

    auth_token = "4da607c4-6185-49eb-acec-216520dd8871"
    cert_file = "d:/dev/QRadar_api_7.2.8/certs/QRadar_52.90.13.59.cer"

    headers = {'Version': '6.0', 'Accept': 'application/json', 'SEC': "4da607c4-6185-49eb-acec-216520dd8871"}
    context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    context.verify_mode = ssl.CERT_NONE
    urllib.request.install_opener(urllib.request.build_opener(
        urllib.request.HTTPSHandler(context=context)))
    if id:
        url = 'https://' + host + '/api/siem/offenses/' + id[0]
    else:
        url = 'https://' + host + '/api/siem/offenses'
    print(url)

    try:
        request = urllib.request.Request(url, headers=headers)
        response = urllib.request.urlopen(request)
        if response.code == 200:
            response_body = json.loads(response.read().decode('utf-8'))
            return response_body
    except:
        return "Connection failed"
