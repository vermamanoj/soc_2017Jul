from django.db import models

class Pessoa(models.Model):
    pass
